# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.loader import ItemLoader
from scrapy.loader.processors import MapCompose, TakeFirst, Join

class AnjukeItem(scrapy.Item):
    # define the fields for your item here like:
    BlockName = scrapy.Field() #小区名字
    Position = scrapy.Field()  #地理位置
    Longitude = scrapy.Field()  #经度
    Latitude = scrapy.Field()   #纬度
    Type = scrapy.Field()  #住房类型
    AllPrice = scrapy.Field() #住房总价格
    PerPrice = scrapy.Field() #平方价
    Size = scrapy.Field() #容积率
    Green = scrapy.Field() #绿化率
    Tax = scrapy.Field() #物业费
    Year = scrapy.Field() #建成年代
    Description = scrapy.Field() #核心卖点
    URL = scrapy.Field() #链接 也用作主键
    Area = scrapy.Field() #地区

class AnjukeItemLoader(ItemLoader):
    #自定义itemloader
    default_output_processor = TakeFirst()


class AnjuCountItem(scrapy.Item):
    CurrentPage = scrapy.Field()
    #记录爬了多少页

