# -*- coding: utf-8 -*-
import scrapy
import re

from scrapy.loader import ItemLoader
from anjuke.items import AnjukeItem
from scrapy.http import Request
from urllib.parse import urlparse
from anjuke.items import AnjukeItemLoader,AnjuCountItem


class AnjuSpider(scrapy.Spider):
    name = 'anju'
    # allowed_domains = ['https://wuhan.anjuke.com']
    start_urls = ['https://wuhan.anjuke.com/sale/wuchanga/',
                 #'https://wuhan.anjuke.com/sale/hongshana/', #finished
                  # 'https://wuhan.anjuke.com/sale/jiangan/', #finished
                  # 'https://wuhan.anjuke.com/sale/hanyang/', #finished
                  # 'https://wuhan.anjuke.com/sale/dongxihu/', #finished
                  # 'https://wuhan.anjuke.com/sale/jiangxiat/', #f
                  # 'https://wuhan.anjuke.com/sale/jianghana/',
                  # 'https://wuhan.anjuke.com/sale/qingshan/',
                  # 'https://wuhan.anjuke.com/sale/qiaokou/',
                  # 'https://wuhan.anjuke.com/sale/huangpiz/',
                  # 'https://wuhan.anjuke.com/sale/zhuankoukaifaqu/',
                  # 'https://wuhan.anjuke.com/sale/caidianz/',
                  # 'https://wuhan.anjuke.com/sale/xinzhouz/',
                  # 'https://wuhan.anjuke.com/sale/hannanz/',
                  # 'https://wuhan.anjuke.com/sale/qitao/',
                  ]

    def parse(self, response):
        print('正在从 ',response.url,' 中爬取房源列表')
        location = response.css('#filtersort > span > strong::text').extract_first()
        print('爬取的区域是: ', location)
        page_urls = response.css('#houselist-mod-new > li > div.house-details > div.house-title > a::attr(href)').extract()
        # print(page_urls)
        for page_url in page_urls:
            o = urlparse(page_url)
            url_without_query_string = o.scheme + "://" + o.netloc + o.path
            yield Request(url=url_without_query_string,meta={"Area": location},callback=self.parse_page)

        next_url = response.css('#content > div.sale-left > div.multi-page > a.aNxt::attr(href)').extract_first()
        print(next_url)
        index_page = re.search(r'\d+',next_url)
        int_index_page = int(index_page.group(0))
        print('第',int_index_page - 1,'页分析完毕')

        count = AnjuCountItem()
        count['CurrentPage'] = next_url
        yield count
        if (int_index_page < 30):
            yield Request(url=next_url,callback=self.parse)
        else:
            print('-------no next--------')



    def parse_page(self,response):
        l = AnjukeItemLoader(AnjukeItem(), response=response)

        #Area
        l.add_value('Area',response.meta['Area'])

        #URL
        l.add_value('URL',response.url)

        #小区名字
        l.add_css('BlockName', '#content > div.wrapper > div.wrapper-lf.clearfix > div.houseInfoBox > div > div > div.houseInfoV2-detail.clearfix > div.first-col.detail-col > dl:nth-child(1) > dd > a::text')  # (1)
        loc1 = response.css('#content > div.wrapper > div.wrapper-lf.clearfix > div.houseInfoBox > div > div > div.houseInfoV2-detail.clearfix > div.first-col.detail-col > dl:nth-child(2) > dd > p > a:nth-child(1)::text').extract_first()
        loc2 = response.css('#content > div.wrapper > div.wrapper-lf.clearfix > div.houseInfoBox > div > div > div.houseInfoV2-detail.clearfix > div.first-col.detail-col > dl:nth-child(2) > dd > p > a:nth-child(2)::text').extract_first()
        # loc3 = response.css('#content > div.wrapper > div.wrapper-lf.clearfix > div.houseInfoBox > div > div > div.houseInfoV2-detail.clearfix > div.first-col.detail-col > dl:nth-child(2) > dd > p::text').extract()[-1].replace(' ','')
        loc3s = response.css('#content > div.wrapper > div.wrapper-lf.clearfix > div.houseInfoBox > div > div > div.houseInfoV2-detail.clearfix > div.first-col.detail-col > dl:nth-child(2) > dd > p::text').extract()
        loc3 = loc3s[-1].replace(' ','')
        loc3 = loc3.replace('\n','')
        loc3 = loc3.replace('－','')
        print(loc3)

        #地理位置
        positon = str(loc1)+'-'+str(loc2)+'-'+str(loc3)
        l.add_value('Position', positon)  # (2)
        scripts = response.xpath('/html/body/script').extract()
        # print(scripts)


        #经纬度
        for script in scripts:
            sscript = str(script)
            if sscript.find('MapOps') > -1:
                # print(str(script).find('MapOps'))
                print('---------------------find mapops----------------')
                # print(script)
                index_lat = sscript.find('lat')
                l.add_value('Latitude',sscript[index_lat+7:index_lat+16])
                # print()
                index_lng = sscript.find('lng')
                l.add_value('Longitude',sscript[index_lng+7:index_lng+17])
                # print()
                print('---------------------find lat,lng----------------')
                # mapops = re.match(r'[a-zA-z]+://[^\s]*', str(script).replace(' ',''))
                # print(mapops)
                # break
            else:
                pass


        #住房类型
        l.add_css('Type','#content > div.wrapper > div.wrapper-lf.clearfix > div.houseInfoBox > div > div > div.houseInfoV2-detail.clearfix > div.first-col.detail-col > dl:nth-child(4) > dd::text')

        #住房总价
        l.add_css('AllPrice','#content > div.wrapper > div.wrapper-lf.clearfix > div.basic-info.clearfix > span.light.info-tag > em::text')

        #平方价
        l.add_css('PerPrice','#content > div.wrapper > div.wrapper-lf.clearfix > div.houseInfoBox > div > div > div.houseInfoV2-detail.clearfix > div.third-col.detail-col > dl:nth-child(2) > dd::text')

        #容积率
        l.add_css('Size','#content > div.wrapper > div.wrapper-lf.clearfix > div.comm-commoninfo > div.cmmmap-info > div:nth-child(4) > p.info-bd::text')

        #绿化率
        l.add_css('Green','#content > div.wrapper > div.wrapper-lf.clearfix > div.comm-commoninfo > div.cmmmap-info > div:nth-child(6) > p.info-bd::text')

        #物业费
        l.add_css('Tax','#content > div.wrapper > div.wrapper-lf.clearfix > div.comm-commoninfo > div.cmmmap-info > div.commap-info-intro.no-border-rg > p.info-bd::text')

        #建成年代
        l.add_css('Year','#content > div.wrapper > div.wrapper-lf.clearfix > div.houseInfoBox > div > div > div.houseInfoV2-detail.clearfix > div.first-col.detail-col > dl:nth-child(3) > dd::text')

        #核心卖点
        l.add_css('Description','#content > div.wrapper > div.wrapper-lf.clearfix > div.houseInfoBox > div > div > div.houseInfoV2-desc > div:nth-child(1) > div > span::text')


        # print(script)
        # print(mapops)
        # l.add_css('name', css)  # (3)
        # l.add_value('name', 'test')  # (4)
        return l.load_item()  # (5)

# o = urlparse('https://wuhan.anjuke.com/prop/view/A938920076?from=filter&spread=filtersearch&position=1&kwtype=filter&now_time=1503380784')

#houselist-mod-new > li > div.house-details > div.house-title > a
# response.css('#houselist-mod-new > li > div.house-details > div.house-title > a::attr(href)')
# response.css('#filtersort > span > strong::text').extract_first()